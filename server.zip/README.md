A simple kanban web application meant to serve as a full stack design challenge.

Currently, core features are being implemented for the front end, with user authentication and database managament to be added in the near future.

Check out the latest deployed version here: \
Warning: The backend needs to be deployed seperately or converted to Lambda functions \
TLDR only the front-end is working \
https://simplekanbanboardio.netlify.app/


Timeline: 
1/26/23 -Project Start\
1/29/23 -Drag and Drop implemented\
2/1/23 -All CRUD operations have been implemented for the front end. \
2/4/23 -MongoDB integration and Express routing basics are complete \
2/18/23 -Board page complete \
2/20/23 -User authentication and web socketing set up
